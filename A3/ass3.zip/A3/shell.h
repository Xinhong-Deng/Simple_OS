/*
 * shell.h
 *
 *  Created on: Jan 18, 2020
 *      Author: sandr
 */

int shellUI(int, char**);
