#ifndef INTERPRETER_H
#define INTERPRETER_H

#include <stdbool.h>
int interpret(char *raw_input, bool isFromScript);

#endif