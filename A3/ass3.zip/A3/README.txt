OS: mimi.cs.mcgill.ca

statusCode.c and statusCode.h:
These files are not required in the assignment document. They are added to handle the errors.
Please make sure you compile them as well.

a bash file and a Makefile are included. They both can compile the code.
The compiled mykernel executable is also included.
